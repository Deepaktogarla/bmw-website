var bodyParser = require("body-parser"),
methodOverride = require("method-override"),
expressSanitizer = require("express-sanitizer"),
mongoose       = require("mongoose"),
express        = require("express"),
app            = express();
    
mongoose.connect("mongodb://deepak:Deepak94@ds119072.mlab.com:19072/deepakdb", { useNewUrlParser: true });


app.use(bodyParser.urlencoded({extended: true}));
app.use(expressSanitizer());
app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(methodOverride('_method'));


//schema
var carSchema = new mongoose.Schema({
    title: String,
    image: String,
    body: String,
    created: {type: Date, default: Date.now}
});
//compiling
var Car= mongoose.model("BMW", carSchema);

// RESTFUL ROUTES

app.get("/", function(req, res){
   res.redirect("/cars"); 
});

// INDEX ROUTE
app.get("/cars",function(req, res){
    
    Car.find({},function(err,cars){
        if(err) {
            console.log("ERROR");
            }  
            else{
                 res.render("index.ejs",{cars:cars});
            }
    
  });
});
  
  // NEW ROUTE
app.get("/cars/new", function(req, res){
    res.render("new");
});

// CREATE ROUTE
app.post("/cars", function(req, res){
    // create blog
    console.log(req.body);
    console.log("===========")
    console.log(req.body);
    Car.create(req.body.car, function(err,newCar){
        if(err){
          
            res.render("new");
            
            
        } else {
            //then, redirect to the index
            
            res.redirect("/cars");
        }
    });
});

// SHOW ROUTE
app.get("/cars/:id", function(req,res){
   Car.findById(req.params.id, function(err,foundCar){
       if(err){
           res.redirect("/cars");
       } else {
           res.render("show", {car:foundCar});
       }
   });
});

// EDIT ROUTE
app.get("/cars/:id/edit", function(req, res){
    Car.findById(req.params.id, function(err, foundCar){
        if(err){
            res.redirect("/cars");
        } else {
            res.render("edit", {car: foundCar});
        }
    });
})


  //update route
  app.put("/cars/:id",function(req, res){
         Car.findByIdAndUpdate(req.params.id,req.body.car,function(err,updatedcar){
     if(err) {
             res.redirect("/cars");
            }  
            else{
                res.redirect("/cars/"+req.params.id);
               
            }
             
         });
    });
    
    //destroy route
    app.delete("/cars/:id",function(req, res){
         Car.findByIdAndRemove(req.params.id,function(err,foundcar){
     if(err) {
             res.redirect("/cars");
            }  
            else{res.redirect("/cars");;
               
            }
             
         });
    });
    
  

app.listen(process.env.PORT, process.IP,function(){console.log("BMW website started working");});
